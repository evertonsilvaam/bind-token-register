//import "/commom/navigate.js"

var args = {
	"bt_type" : "Valid",
	"bt_value": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2MjU3Njk1MTUsImV4cCI6MTY1NzMwNTUxNSwibmJmIjoxNjI1NzY5NTE1LCJpc3MiOiJUUFYgUUEgVGVhbSIsIm5hbWUiOiJzZXJ2aWNlLTEiLCJzdWIiOiJ2YWxpZCB0b2tlbiJ9."
}

function gerarQRCode(bind_token, service_context_id)		
{
  var conteudo = {
  	"bind_token": bind_token,
  	"service_context_id": service_context_id,
  }

  var GoogleCharts = 'https://chart.googleapis.com/chart?chs=500x500&cht=qr&chl=';
  var imagemQRCode = GoogleCharts + JSON.stringify(conteudo);
  console.log(conteudo)
  document.getElementById('qrcode').src = imagemQRCode; 
}

function set_bt_value(bind_token, bt_type, service_context_id){
	var bt_title = document.getElementById("bt_title");
	bt_title.innerHTML = bt_type + " Bind Token";

	var bt_code = document.getElementById("bt_code");
	bt_code.innerHTML = bind_token;
}