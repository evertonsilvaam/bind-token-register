/*
	Author: Everton da Silva e Silva
	Date: 2021, July
*/

//Adicionando eventos do controle à página
window.addEventListener("keydown", function(event) {
	key_event(event.keyCode)
}, true);

const registred_bind_tokens = []

var navigation_args = {
	"current_index" : 1,
	"max_index": 12,
	"min_index": 1,
	"selected_index": 1
}

var service_context_id = undefined

const focus = {
	1 : "bt_servico_1_valid",
	2 : "bt_servico_1_invalid",
	3 : "bt_servico_1_revoked",
	4 : "bt_servico_1_outdated",
	5 : "bt_servico_2_valid",
	6 : "bt_servico_2_invalid",
	7 : "bt_servico_2_revoked",
	8 : "bt_servico_2_outdated",
	9 : "bt_servico_3_valid",
	10 : "bt_servico_3_invalid",
	11 : "bt_servico_3_revoked",
	12 : "bt_servico_3_outdated",
}

const token_registered = [
	"bt_servico_1_valid_registered",
	"bt_servico_1_invalid_registered",
	"bt_servico_1_revoked_registered",
	"bt_servico_1_outdated_registered",
	"bt_servico_2_valid_registered",
	"bt_servico_2_invalid_registered",
	"bt_servico_2_revoked_registered",
	"bt_servico_2_outdated_registered",
	"bt_servico_3_valid_registered",
	"bt_servico_3_invalid_registered",
	"bt_servico_3_revoked_registered",
	"bt_servico_3_outdated_registered"
]

var b_token_list = {
	"tokens":[
		{
			"service": 1,
			"type": "Valid",
			"value":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2MjU3Njk1MTUsImV4cCI6MTY1NzMwNTUxNSwibmJmIjoxNjI1NzY5NTE1LCJpc3MiOiJUUFYgUUEgVGVhbSIsIm5hbWUiOiJzZXJ2aWNlLTEiLCJzdWIiOiJ2YWxpZCB0b2tlbiJ9."
		},
		{
			"service": 1,
			"type": "Invalid",
			"value":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2MjYyODIyNjIsIm5iZiI6MTYyNjI4MjI2MiwiaXNzIjoiVFBWIFFBIFRlYW0iLCJuYW1lIjoic2VydmljZV8xIiwic3ViIjoiaW52YWxpZCB0b2tlbiJ9."
		},
		{
			"service": 1,
			"type": "Revoked",
			"value":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2MjYyODIzMjUsImV4cCI6MTY1NzgxODMyNSwibmJmIjoxNjI2MjgyMzI1LCJpc3MiOiJUUFYgUUEgVGVhbSIsIm5hbWUiOiJzZXJ2aWNlXzEiLCJzdWIiOiJyZXZva2VkIHRva2VuIn0."
		},
		{
			"service": 1,
			"type": "Outdated",
			"value":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2MjYyODI2NjgsImV4cCI6MTYyNjI4MjcyOCwibmJmIjoxNjI2MjgyNjY4LCJpc3MiOiJUUFYgUUEgVGVhbSIsIm5hbWUiOiJzZXJ2aWNlXzEiLCJzdWIiOiJvdXRkYXRlZCB0b2tlbiJ9."
		},
		{
			"service": 2,
			"type": "Valid",
			"value":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2MjYyODMxMjksImV4cCI6MTY1NzgxOTEyOSwibmJmIjoxNjI2MjgzMTI5LCJpc3MiOiJUUFYgUUEgVGVhbSIsIm5hbWUiOiJzZXJ2aWNlXzIiLCJzdWIiOiJ2YWxpZCB0b2tlbiJ9."
		},
		{
			"service": 2,
			"type": "Invalid",
			"value":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2MjYyODMxNDksIm5iZiI6MTYyNjI4MzE0OSwiaXNzIjoiVFBWIFFBIFRlYW0iLCJuYW1lIjoic2VydmljZV8yIiwic3ViIjoiaW52YWxpZCB0b2tlbiJ9."
		},
		{
			"service": 2,
			"type": "Revoked",
			"value":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2MjYyODMxNjksImV4cCI6MTY1NzgxOTE2OSwibmJmIjoxNjI2MjgzMTY5LCJpc3MiOiJUUFYgUUEgVGVhbSIsIm5hbWUiOiJzZXJ2aWNlXzIiLCJzdWIiOiJyZXZva2VkIHRva2VuIn0."
		},
		{
			"service": 2,
			"type": "Outdated",
			"value":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2MjYyODMxMTAsImV4cCI6MTYyNjI4MzE3MCwibmJmIjoxNjI2MjgzMTEwLCJpc3MiOiJUUFYgUUEgVGVhbSIsIm5hbWUiOiJzZXJ2aWNlXzIiLCJzdWIiOiJvdXRkYXRlZCB0b2tlbiJ9."
		}
	]
}

//Busca o Bind Token Válido Dinâmico de outro app
function register_dinamic_bind_token(app_name, token_type){

	var protocol = "http";
	var ip = "rd-mediaserver.aoc.com.br";
	var port = "9087";
	var route = "bind-token-manager/"+token_type+"?app-name=";

	var params = {	"method": "GET",
					"Access-Control-Request-Headers" : "Content-Type",
					"Content-Type" : "application/json",
					"mode":"no-cors"};

	var url = "";

	// var aux = {
	// 	"service" : 3,
	// 	"type": token_type,
	// 	"value" : token,
	// }
	// b_token_list.push(aux)


	//var param = app_name;

	switch (token_type) {
		case "valid":
		case "invalid":
		case "revoked":
			
			url = protocol+"://"+ip+":"+port+"/"+route+app_name;

		break;
		case "outdated":

			url = protocol+"://"+ip+":"+port+"/"+route+app_name+"&time="+1;

		break;
	}

	console.log("URL", url)



	var fetch_promise = Promise.resolve(fetch(url, params));
	// Promise.resolve(fetch_promise).then(function (value) {
	// 	console.log("value", value);

	// }, function(value){
	// 	console.log("value @", value)
	// });

	fetch_promise.then(response => {
		// response.setHeader(
		// 	"Access-Control-Allow-Origin", url
		// 	);
		console.log("RESPONSE", JSON.stringify(response))
		console.log("RESPONSE", response)
		console.log("response type", response.type);
		console.log("response 1.5 ", response.body)
		var res = response.blob()
		return res;
	}).then(res => {
		// console.log("response 2 ", res.map())

		console.log("response 2.2", JSON.stringify(Promise.resolve(res)))

		var reader = new FileReader();
		var txt = reader.readAsArrayBuffer(res);

		console.log("response 2.5 ", res.arrayBuffer())
		console.log("response 2.5 ", res.body)


		// var log = "URL: "+request_type+" "+url+" Params: "+JSON.stringify(params)+" RESPONSE: "+JSON.stringify(response);
		// add_log_line(get_time_now(), log);
		//add_log_line(get_time_now(), JSON.stringify(response));
		// var aux = {
		// 	"service" : 3,
		// 	"type": token_type,
		// 	"value" : response["token"],
		// }
		// console.log("AUX", aux)
		return res;
	// }).then(response => {
	// 	console.log("response 3", response)
	// 	return response;
	}).then(res => {
		console.log("response 4", res)
		return res

	}).catch(error => {
		console.error(error)
		add_log_line('Error', error);
		// set_tb_status(navigation_args["current_index"], token, true, true)
		// return false;
	});


}

// ######################  Funcoes do Controle *INICIO*
//Funções atribuidas para navegação utlizando controle da TV
 function key_event(key_code){
	text = "";
	switch (key_code){
		case 403:
			text = "Red"
			close_app()
		break;
		case 404:
			text = "Green";
		break;
		case 405:
		case 89: //botao Y no teclado
			text = "Yellow"
			
		break
		case 406:
			text = "Blue"
		break;
		case 13:
			text = "Enter"
			on_select()
		break;
		case 38:
		case 87: //teclado
			text = "Up";
			scrollLog('up')
			
		break;
		case 40:
		case 83: //teclado
			text = "Down"
			scrollLog('down')
			
		break;
		case 37:
		case 65: //teclado
			text = "Left"
			navigate_left()
			// check_service_selected()
		break;
		case 39:
		case 68: //teclado
			text = "Right"
			navigate_right()
			// check_service_selected()
		break;
		case 461:
		case 8: //Backspace Teclado
			text = "Back"
			// navigate_return()
		break;
		default:
			text = key_code
			console.log(text);
			break

	}
	return text
}

// ######################  Funcoes do Controle *FIM*


//Função padrão para enviar requests
function send_request(request_type, route, token, param, label){
	//ex: send_request("GET", "bind-context","token", "valid", "Válido")

	var protocol = "http";
	var host = "localhost"
	var port = "44642"
	// var protocol = "https";
	// var port = "44643"
	// var host = "172.31.142.43";
	
	var url = protocol+'://'+host+':'+port+"/dtv/"+route

	//request = new Request(url)
	
	var params = {
		method: request_type,
		headers: {"bind-token": token,
				  "Accept": "application/json",
				  "Content-Type": "application/json"
				}
	}

	console.log(request_type+" "+url)
	// console.log("args"+" "+JSON.stringify(params))

	var fetch_promise = fetch(url, params);
	fetch_promise.then(response => {
		return response.json();
	}).then(response => {
		console.log("response", response)
		var log = "URL: "+request_type+" "+url+" Params: "+JSON.stringify(params)+" RESPONSE: "+JSON.stringify(response);
		add_log_line(get_time_now(), log);
		//add_log_line(get_time_now(), respose.status);
		service_context_id = response["serviceContextId"]
		set_service_context_id(response["serviceContextId"]);
		set_tb_status(navigation_args["current_index"], token, true, false)
		return true;
	}).catch(error => {
		console.error(error)
		add_log_line('Error', error);
		set_tb_status(navigation_args["current_index"], token, true, true)
		return false;
	});

}

function set_service_context_id(service_context_id){
	var scid = document.getElementById("service_context_id");
	scid.innerHTML = "Service Context Id "+service_context_id
}



function register_bind_token(token, type) {
	send_request("POST", "bind-context", token, "", "");
}

function remove_bind_token(token, type) {
	send_request("DELETE", "bind-context", token, "", "");
}


function get_bind_token(token){
	var protocol = "http";
	var host = "localhost";
	var port = "44642";
	var route = "bind-context";
	var url = protocol+'://'+host+':'+port+"/dtv/"+route

	var params = {
		method: "GET",
		headers: {
			"bind-token": token
		}
	}

	const fetch_promise = fetch(url, params);
	fetch_promise.then(response => {
		return response.json();
	}).then(response => {
		console.log("response", response);
		if (!response["error"].hasOwnProperty('error')){
			add_log_line('GET', "URL "+url+/*" PARAMS "+JSON.stringify(params)+*/" RESPONSE "+JSON.stringify(response));
			return true;
		} else {
			add_log_line('GET Error', "URL "+url+/*" PARAMS "+JSON.stringify(params)+*/" RESPONSE "+JSON.stringify(response));
			return false;
		}
		
	}).catch(error => {
		console.error(error)
		add_log_line('Error', error);
		return false;
	});

}


function set_tb_status(index, b_token, status, error){
	var obj = document.getElementById(token_registered[navigation_args["current_index"]-1])
	if (status) {
		if (error){
			obj.src = "images/erro.png"
			obj.className = "icon_commom"	
		} else {
			obj.src="images/ok.png"
			obj.className = "icon_commom"	
		}
		
	} else {
		obj.className = "icon_commom bt_not_saved"
	}

}

function check_bt_selected(){
	var obj_focus = document.getElementById(focus[navigation_args["current_index"]])
	obj_focus.className = "service_commom service_focus";
}

window.onload = function(){
	console.log("current_index",navigation_args["current_index"])
	remove_focus_all()
	check_bt_selected()
	//check_all_persist_bindtokens_fixed()
	
}

function check_all_persist_bindtokens_fixed() {
	//console.log("persist", b_token_list["tokens"].length)
	for (var i = 0; i < b_token_list["tokens"].length; i ++){
		// console.log("focus ",i)
		if (get_bind_token(b_token_list["tokens"][i]["value"])){
			console.log(i+" OK ")
		} else {
			console.log(i+" NOT OK ")
		}	
	}
}

function remove_focus_all() {
	document.getElementById("bt_servico_1_valid").className = "service_commom";
	document.getElementById("bt_servico_1_invalid").className = "service_commom";
	document.getElementById("bt_servico_1_revoked").className = "service_commom";
	document.getElementById("bt_servico_1_outdated").className = "service_commom";
	document.getElementById("bt_servico_2_valid").className = "service_commom";
	document.getElementById("bt_servico_2_invalid").className = "service_commom";
	document.getElementById("bt_servico_2_revoked").className = "service_commom";
	document.getElementById("bt_servico_2_outdated").className = "service_commom";
	document.getElementById("bt_servico_3_valid").className = "service_commom";
	document.getElementById("bt_servico_3_invalid").className = "service_commom";
	document.getElementById("bt_servico_3_revoked").className = "service_commom";
	document.getElementById("bt_servico_3_outdated").className = "service_commom";
}

function navigate_left(){

	if (navigation_args["current_index"] > 12) {
		console.log("blocked")
	} else {
		if (navigation_args["current_index"] == navigation_args["min_index"]){
			navigation_args["current_index"] = navigation_args["max_index"];
		}
		else if (navigation_args["current_index"] > navigation_args["min_index"]){
		 	navigation_args["current_index"] = navigation_args["current_index"] - 1;
		}


		remove_focus_all()
		var obj_focus = document.getElementById(focus[navigation_args["current_index"]])
		obj_focus.className = "service_commom service_focus";

		console.log("current_index", navigation_args["current_index"])	
		}
}


function navigate_right(){
	

	if (navigation_args["current_index"] > 12) {
		console.log("blocked")
	} else {
		if (navigation_args["current_index"] == navigation_args["max_index"]){
			navigation_args["current_index"] = navigation_args["min_index"];
		}
		else if (navigation_args["current_index"] < navigation_args["max_index"]){
		 	navigation_args["current_index"] = navigation_args["current_index"] + 1;
		} 

		remove_focus_all()
		var obj_focus = document.getElementById(focus[navigation_args["current_index"]]);
		console.log(obj_focus)
		obj_focus.className = "service_commom service_focus";

		console.log("current_index", navigation_args["current_index"])	
	}
}


function on_select(){
	// var index = navigation_args["current_index"] - 1
	var token_type = 0;
	// send_request("POST", route, token, param, label)
	if (navigation_args["current_index"]<=12){
		switch (navigation_args["current_index"]){
			case 1:
			case 2:
			case 5:
			case 6:
				send_request("POST", "bind-context", b_token_list["tokens"][navigation_args["current_index"]-1]["value"], "", "");
			break
			case 3:
			case 7:
				send_request("POST", "bind-context", b_token_list["tokens"][navigation_args["current_index"]-1]["value"], "", "");
				setTimeout(function(){
					send_request("DELETE", "bind-context", b_token_list["tokens"][navigation_args["current_index"]-1]["value"], "", "");
				},2000);
			break
			case 4:
			case 8:
				send_request("POST", "bind-context", b_token_list["tokens"][navigation_args["current_index"]-1]["value"], 1, "")
			break;
			case 9:
				register_dinamic_bind_token("service-3", "valid");
			break;
			case 10:
				register_dinamic_bind_token("service-3", "invalid")
			break;
			case 11:
				register_dinamic_bind_token("service-3", "revoked")
			break;
			case 12:
				register_dinamic_bind_token("service-3", "outdated")
				setTimeout(function(){
					send_request("POST", "bind-context", b_token_list["tokens"][navigation_args["current_index"]-1]["value"], 1, "")
				}, 2000)
			break;
		}
		//send_request()
		//gerarQRCode(b_token_list["tokens"][navigation_args["current_index"]-1]["value"], service_context_id);
		//set_bt_value(b_token_list["tokens"][navigation_args["current_index"]-1]["value"], b_token_list["tokens"][navigation_args["current_index"]-1]["type"], service_context_id);

		//remove_focus_all()
		
		var obj_focus = document.getElementById(focus[navigation_args["current_index"]]);
	}

	console.log("current_index", navigation_args["current_index"])
	//add_log_line("","")
	
}


function remove_service_selection(){
	var service_1 = document.getElementById("bt_gerar_bind_token_servico_1")
	var service_2 = document.getElementById("bt_gerar_bind_token_servico_2")
	var service_3 = document.getElementById("bt_gerar_bind_token_dinâmico")

	service_1.className = "bt_gerar_bind_token_servico"
	service_2.className = "bt_gerar_bind_token_servico"
	service_3.className = "bt_gerar_bind_token_servico"

}

function check_service_selected(){
	remove_service_selection()
	if (navigation_args["current_index"]<=4){
		var service_1 = document.getElementById("bt_gerar_bind_token_servico_1");	
		service_1.className = "bt_gerar_bind_token_servico service_focus";
	} else if(navigation_args["current_index"]<=8){
		var service_2 = document.getElementById("bt_gerar_bind_token_servico_2");
		service_2.className = "bt_gerar_bind_token_servico service_focus";
	} else if (navigation_args["current_index"]<=12) {
		var service_3 = document.getElementById("bt_gerar_bind_token_dinâmico");
		service_3.className = "bt_gerar_bind_token_servico service_focus";
	}
}

function close_app(){
	if (navigation_args["current_index"] < 13){
		window.close()
	}
}


function add_log_line(hour, log, error){
	var table = document.getElementById("log_table");
	if (table.rows.length>1) {
		table.deleteRow(1);	
	}
	//console.log("linhas", table.rows.length);

	var new_row = table.insertRow();

	console.log(hour+" "+log);

	var cell_hour = new_row.insertCell(0)
	var cell_log = new_row.insertCell(1)

	cell_hour.innerHTML = hour;
	cell_log.innerHTML = log;

	//table.scrollY(table.rows.length)

	
}

function get_time_now(){
	var data = new Date();
	var str = "";
	str = data.getHours()+":"+data.getMinutes()
	return str;
}


function scrollLog(move) {
	console.log('scrollLog')
	switch(move){
		case 'up':
			document.getElementById('log').scrollBy(0, -100);
		break;
		case 'down':
			document.getElementById('log').scrollBy(0, 100);
		break;
		default:
			console.log('movimento errado')
	}
}