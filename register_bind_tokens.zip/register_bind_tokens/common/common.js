/*
    Este arquivo importa todas as bibliotecas js que serão utilizadas pelos apps.
 */

/*
    Coloque abaixo todos os arquivos .js que serão utilizados por todos os Apps
    Obs: Considere que a base para importação é a partir da pasta js/
 */

// Para a utilização do polyfill fetch
window.fetch = null;

// Para a utilização do polyfill Promise
window.Promise = null;

var IMPORTS = [
    // "utils/PolyfillPromise.js",
    // "utils/PolyfillFetch.js",
    // "utils/PolyfillTypedArray.js",

    // "consts/TransportStream.js",
    // "consts/ErrorsReturn.js",
    // "consts/TCsReturn.js",
    // "consts/AddressReturn.js",
    // "consts/TokensReturn.js",
    // "consts/RouteParamsReturn.js",

    "Utils.js",
    // "utils/Files.js",
    // "utils/jwt-decode.js",
    // "DAO/ReferenceDAO.js",
    // "qrcode.min.js",
    // "library/crypto.js",
    // "DAO/dataStorageDAO.js",
    "resultGenerator.js",
    // "tools/buttonDTVSelect.js",
    // "tools/cryptographyHandler.js",
    // "tools/QRCodeReader.js",
];


/**
 * Como os apps ficaram na pasta App, o BASE_PATH (diretório raiz) estará dois níveis acima
 * @type {string}
 */
var BASE_PATH = '../';

/**
 * @return {string}
 */
function PATH_FROM_BASE(pathFromBase) {
    var arrayBasePath = BASE_PATH.split('/').concat(pathFromBase.split('/'));


    arrayBasePath = arrayBasePath.filter(
        function (val) {
            return !!val;
        });

    return arrayBasePath.join('/');
}


// Função para importar a biblioteca de qrcode, leitor e escrita de webStorage e leitor de json
// Foi necessário replicá-la aqui, pois utils/Utils.js ainda não importado
function include(filename, type) {
    var head = document.getElementsByTagName('head')[0];

    var script = document.createElement('script');
    script.src = filename;
    script.type = type ? type : "text/javascript";
    script.async = false;

    head.appendChild(script)
}

/*
    A importação considera que os apps sejam criados na pasta Apps
 */
IMPORTS.forEach(function(val, index) {
   include(PATH_FROM_BASE('js/' + val));
});
